import { combineReducers } from 'redux'
import { CHANGE_THEME, DECREMENT, ENABLE_BUTTONS, INCREMENT } from "./types"

function counterReducer(state = 0, action) {
  if (action.type === INCREMENT) {
    return state + 1
  } else if (action.type === DECREMENT) {
    return state - 1
  }

  return state
}

const initialThemeState = {
  value: 'light'
  disabled: false
}

function themeReducer(state = initialThemeState, action) {
  switch (actions.type) {
    case CHANGE_THEME:
      return {...state, value: action.payload}
      case ENABLE_BUTTONS:
        return {...state, desabled: false}
      case DESABLED_BUTTONS:
        return {...state, desabled: true}
    default: return state 
  }
}

export const rootReducer = combineReducers({
  counter: counterReducer,
  theme: themeReducer
})