import './styles.css'

const counter = document.getElementById(elementId: 'counter')
const addBtn = document.getElementById(elementId: 'add')
const subBtn = document.getElementById(elementId: 'sub')
const asyncBtn = document.getElementById(elementId: 'async')
const themeBtn = document.getElementById(elementId: 'theme')

let state = 0

function render() {
  counter.textContent = state.toString()
}

addBtn.addEventListener(type: 'click', listener: () => {
  state++
  render()
})

subBtn.addEventListener(type: 'click', listener: () => {
  state--
  render()
})

asyncBtn.addEventListener(type: 'click', listener: () => {
  setTimeout(handler: () => {
    state++
    render()
  }, timeout: 2000)
})

themeBtn.addEventListener(type: 'click', listener: () => {
  document.body.classList.toggle(token: 'dark')
})

render()
